class Translation(object):
    START_TEXT = """Hello,
This is a Telegram File convert Bot!
You can convert any Telegram Document, using this bot! With custom thumbnail
     
    """
    ABS_TEXT = " Please don't be selfish."
    BANNED_USER_TEXT = "you are banned"
    UPGRADE_TEXT = "No upgrade plan 🥰"
    DOWNLOAD_START = "trying to download"
    UPLOAD_START = "trying to upload"
    RCHD_BOT_API_LIMIT = "size greater than maximum allowed size (50MB). Neverthless, trying to upload."
    AFTER_SUCCESSFUL_UPLOAD_MSG = "https://t.me/fileConvertRobot"
    AFTER_SUCCESSFUL_UPLOAD_MSG_WITH_TS = "Downloaded in {} seconds. \nPlease rate me if you find me useful. https://t.me/tlgrmcbot?start=anydl_bot-bot \nUploaded in {} seconds."
    NOT_AUTH_USER_TEXT = "Please /upgrade your subscription."
    SAVED_CUSTOM_THUMB_NAIL = "Custom video / file thumbnail saved. This image will be used in next 24 hr"
    DEL_ETED_CUSTOM_THUMB_NAIL = "✅ Custom thumbnail cleared succesfully."
    FF_MPEG_DEL_ETED_CUSTOM_MEDIA = "✅ Media cleared succesfully."
    SAVED_RECVD_DOC_FILE = "Document Downloaded Successfully."
    CUSTOM_CAPTION_UL_FILE = ""
    NO_CUSTOM_THUMB_NAIL_FOUND = "No Custom ThumbNail found."
    CURENT_PLAN_DETAILS = """Current plan details
--------
Telegram ID: <code>{}</code>
Plan name: <a href='https://t.me/InFoTelGroup/174'>{}</a>
Expires on: {}"""
    HELP_USER = """I can do:
👉 <a href="https://telegram.dog/FileConvertRobot">Convert To Streamable video any telegram file</a>
--------

🔥 How to deploy : <a href='https://youtu.be/zQamSjXBpJU'>Click here</a>

    © Group   : @InfotelGroup
    © Channel : @DX_BotZ 
    © credits : @Spechide

Send /me to know current plan details

"""

    REPLY_TO_DOC_FOR_C2V = "Reply to a Telegram media to convert"
