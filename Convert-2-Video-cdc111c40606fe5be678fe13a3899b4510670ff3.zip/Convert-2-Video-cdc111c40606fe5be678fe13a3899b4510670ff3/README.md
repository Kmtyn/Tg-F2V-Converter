## [Anydl Robot](https://telegram.dog/Anydl)
---

An Open Source Telegram RoBot  😍

### Special thanks

* [@Spechide](https://telegram.dog/spechide)

### Installation

#### The Easy Way

[![Deploy](https://www.herokucdn.com/deploy/button.svg)](https://heroku.com/deploy)

## Our Telegram Channel and Group

* [Dx Bots Updates](https://telegram.dog/Dx_Botz)

* [InFoTel Group](https://telegram.dog/InFoTelGroup)


### [@BotFather](https://telegram.dog/BotFather) Commands

```
start - Check if the Bot is Online!
help - How to use this Bot?
upgrade - Upgrade your status
converttovideo - Convert to Streamable Video
```

